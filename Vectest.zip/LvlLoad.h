#ifndef LVLLOAD_H
#define LVLLOAD_H

void levelLoader();

#endif /* LVLLOAD_H */
