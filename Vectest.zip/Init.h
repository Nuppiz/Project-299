#ifndef INIT_H
#define INIT_H

void deinitClock();
void mainInit();
void titleInit();
void menuInit();
void gameInit();
void pauseInit();
void ingameMenuInit();

#endif /* INIT_H */
