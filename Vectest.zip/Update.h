#ifndef UPDATE_H
#define UPDATE_H

void titleUpdate();
void menuUpdate();
void gameUpdate();
void pauseUpdate();
void ingameMenuUpdate();

#endif /* UPDATE_H */
