#ifndef INPUT_H
#define INPUT_H

void processKeyEvents();
void clearKeys();
void gameInput();
void titleInput();
void pauseInput();

#endif/* INPUT_H */
