#ifndef KEYB_H
#define KEYB_H

#include "Common.h"
#include "Keys.h"

extern uint8_t* g_Keyboard;

void initKeyboard();
void deinitKeyboard();

#endif/* KEYB_H */
