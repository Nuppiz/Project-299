#ifndef INIT_H
#define INIT_H

void deinitClock();
void mainInit();
void titleInit();
void gameInit();
void pauseInit();

#endif /* INIT_H */
