#ifndef AI_H
#define AI_H

void AILoop();

#endif /* AI_H */
