#ifndef EXIT_H
#define EXIT_H

void titleExit();
void gameExit();
void pauseExit();

#endif /* EXIT_H */
