#ifndef EXIT_H
#define EXIT_H

void titleExit();
void menuExit();
void gameExit();
void pauseExit();
void ingameMenuExit();

#endif /* EXIT_H */
