#ifndef STATE_H
#define STATE_H

void pushState(int state_index);
void popState();

#endif /* STATE_H */
