#ifndef PATCH_H
#define PATCH_H

void patchMidasSetTimer(void far *setTimerBxHook);

#endif/* PATCH_H */
